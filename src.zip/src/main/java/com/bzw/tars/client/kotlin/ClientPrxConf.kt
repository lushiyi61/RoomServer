package com.bzw.tars.client.kotlin

/**
 * @创建者 zoujian
 * @创建时间 2018/8/14
 * @描述
 */

class ClientPrxConf {
    var clientPrxList: MutableList<MutableMap<String, String>> = mutableListOf();
}

