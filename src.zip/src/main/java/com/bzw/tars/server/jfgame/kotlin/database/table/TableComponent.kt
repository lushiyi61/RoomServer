package com.bzw.tars.server.jfgame.kotlin.database.table

/**
 * @创建者 zoujian
 * @创建时间 2018/7/25
 * @描述
 */
abstract class TableComponent(val name: String) {
    abstract fun ToString(): String;
}