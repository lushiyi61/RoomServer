package com.bzw.tars.server.jfgame.kotlin.database.table

/**
 * @创建者 zoujian
 * @创建时间 2018/8/15
 * @描述
 */
enum class TableType {
     E_ROOM_GOLD,    // 金币场
     E_ROOM_CARD,    // 房卡场
     E_ROOM_FREE,    // 免费场
}