package com.bzw.tars.server.jfgame.kotlin.database.player

/**
 * @创建者 zoujian
 * @创建时间 2018/7/26
 * @描述
 */
class CPlayerTreasureInfo : PlayerComponent("CPlayerTreasureInfo") {

    override fun ToString(): String {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}