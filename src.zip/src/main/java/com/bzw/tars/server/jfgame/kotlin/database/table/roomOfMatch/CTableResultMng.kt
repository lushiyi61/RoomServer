package com.bzw.tars.server.jfgame.kotlin.database.table.roomOfMatch

import com.bzw.tars.server.jfgame.kotlin.database.table.TableComponent

/**
 * @创建者 zoujian
 * @创建时间 2018/8/21
 * @描述 游戏结果管理
 */
class CTableResultMng : TableComponent {
    constructor() : super("CTableResultMng") {
    }

    override fun ToString(): String {
        var tmpStr = "CTableResultMng:\n";
        return tmpStr;
    }
}