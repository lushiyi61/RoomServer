package com.bzw.tars.server.jfgame.kotlin.database.room

import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.*

/**
 * @创建者 zoujian
 * @创建时间 2018/7/11
 * @描述
 */
class RoomMngTest {
    @Test
    fun test()
    {
//        RoomMng.getInstance().Get("111");
    }

    @Test
    fun set() {
    }

    @Test
    fun get() {
    }

}
